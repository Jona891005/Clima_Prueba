//Author: Jonathan Espitia
//Desarrollador  Web Movil
//6 Diciembre 2019 
import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Geolocation } from '@ionic-native/geolocation';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';
import { LoadingController } from 'ionic-angular';
import { AlertController } from 'ionic-angular';
import * as $ from "jquery";


@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  lat: any;
  log: any;
  timezone: any;
  Respuesta: any;
  SecretKey = "79f3c4db4e76b526b6c728a069f9e416";
  Sumarry: any;
  constructor(public alertCtrl: AlertController, public http: Http, public loadingCtrl: LoadingController, private geolocation: Geolocation, public navCtrl: NavController) {

  }

  ionViewDidLoad() {
    //Metodo inicla para la espera de la carga
    this.presentLoading();
  }
  //Obtener Posicionamiento del dispositivo
  Posicionamiento() {
    this.geolocation.getCurrentPosition().then((resp) => {
      this.lat = resp.coords.latitude;
      this.log = resp.coords.longitude;
    }).catch((error) => {
      console.log('Error getting location', error);
    });

    let watch = this.geolocation.watchPosition();
    watch.subscribe((data) => {
      //Consumo servicio estado del clima 
      this.ConsulotarClima(data.coords.latitude, data.coords.longitude);

    });
  }

  //Metodo que obtiene el estado del tiempo consumido por metodos ajxa y jquery
  ConsulotarClima(lat, log) {
    let myData: any;
    var Sumarry;
    $.ajax({
      url: 'https://api.darksky.net/forecast/' + this.SecretKey + '/' + lat + ',' + log,
      data: myData,
      type: 'GET',
      crossDomain: true,
      dataType: 'jsonp',
      success: function (data) {
        $('#Nombre').text(data['timezone']);
        $('#sumarry').text(data['currently']['summary']);
        $('#rain').text(data['currently']['precipProbability']);
        $('#humidity').text(data['currently']['humidity']);
        $('#temperature').text(data['currently']['temperature']);

        var f = document.getElementById('myBar');

        f.style.width = data['currently']['temperature'] + "%";
      },
      error: function () { alert('Fallo el servicio!'); }
    });

  }

  //Metodo para Rfrescar la Pagina
  Refresh() {
    this.presentLoading();
  }

  //Metodo de estado espera y carga de info
  presentLoading() {
    const loader = this.loadingCtrl.create({
      content: "Espere por favor...",
      duration: 3000
    });
    this.Posicionamiento();
    loader.present();
  }



}
